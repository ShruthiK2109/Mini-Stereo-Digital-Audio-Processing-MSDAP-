// Shruthi Krishnamithran (skm210012)
// Dhavala Bhat (dxb220000)

#include <iostream>
#include <iomanip> 
#include <fstream> 
#include <string> 
#include <bitset>

using namespace std;
string int_to_bin (unsigned int a)	// This function coverts a decimal value to binary string.
{
string binary_number; 
string st, M; 
M = "0";
int x = 0;
int bit_size = 16; 
while(a!=0) {
binary_number=(a%2==0 ?"0":"1")+binary_number; 
a/=2;
}
if (binary_number.length()==bit_size) 
return binary_number;
 
else
{

x = bit_size-binary_number.length(); 
for (int i = 0; i< x; i++)
{
 
st = st.append(M);
}
st.append(binary_number);
}
return st;
}

unsigned int hex_to_int(string a){	// This function is an intermediate function to convert hexadecimal value to decimal value.
unsigned int x = 0; 
sscanf(a.c_str(),"%x",&x); 
return x;
}

unsigned int bit40conv(string a)	// This function converts out 16bit input into 40bit value.
{
string b, temp; 
unsigned int y =0;
unsigned int bit40num = 0; 
int size = 16;
y = hex_to_int(a); 
temp = int_to_bin(y); 
if (temp[0] == '1')
{
 b = "FF";
b.append(a);

}
else
{
b = "00";
b.append(a);

}

 
b.append("0000"); 
bit40num = hex_to_int(b);
 
return bit40num;
}

long unsigned int convolute(string a, string b, signed int x){	// This function performs the bit shift and addition that is required to find y[n]
long unsigned int sum = 0; 
int sign = 0;
for (int i = 0; i < 16; i++){ 
if (b[i]=='1'){
if (a[i] == '1'){
sign = -1;
}
else {
sign = 1;
}
sum = sum + sign*(x>>(i+1));

}
}
return sum;
}
 
int main(int argc, char *argv[])
{
fstream File;	//File stream to open the input, coefficient file and the output file. int coef1,coef2,i,n;
int coef1, coef2, i, n;
unsigned int xin[1000]; 
string c,x;
long unsigned int y[1000]; 
string signbit[256],POT[256];
File.open("data.in");	//opening inputfile to read the 1000 input value 
if (!File)
{
cout << "Unable to open data input file"; 
return 1;
} 
i=0;
while (File >> x)
{
xin[i]=bit40conv(x); 
i++;
}
File.close();
File.open("coeff.in");	//opening coefficient file to read the 256 value 
if (!File)
{
cout << "Unable to open coeff file"; 
return 1;
} 
i=0;
while (File >> c)	//Dividing coefficient data into 2 halves to find POT and signedbit
{
signbit[i]= c.substr(0,4); 
POT[i]= c.substr(4); 
coef1=hex_to_int(signbit[i]); 
coef2=hex_to_int(POT[i]); 
signbit[i]=int_to_bin(coef1); 
POT[i]=int_to_bin(coef2); 
i++;
}
File.close();
 
File.open("output.out");	//Opening output file to store out output data 
if (!File)
{
cout << "Unable to open output file"; 
return 1;
}
for (n=0;n<1000;n++)
{
y[n]=0;
for (i=0;i<256;i++)
{
if (i<=n)
{
y[n]= y[n] + convolute(signbit[i],POT[i],xin[n-i]);
// convoluting n[k] and x[n-k]
}
}
File<<setfill('0') << setw(10)<<std::uppercase<<std::hex<<(y[n]&0Xffffffffff)<<endl;	// storing the output data in our output file
}
return 0;
}
